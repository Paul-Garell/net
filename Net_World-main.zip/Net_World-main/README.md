# Net_World


#Small project that stores in SQL database. Integrates lite version of sql library for python. Use sqlite3, flask, html 5, python 3.6<. 

